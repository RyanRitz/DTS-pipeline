"""
run_pipeline.py
===============
BTSM daily pipeline orchestrator. Runs every 30 minutes via Task Scheduler.

State machine per (race_date, track):
  PREVIEW SHEET  — published as soon as DRF arrives. No scratches.
                   Re-published if DRF mtime changes (BRISnet updated the file).
  FINAL SHEET    — published 30-60 min before first post on race day.
                   Includes scratches, jockey changes, surface/condition changes.

Each tick of this script:
  1. Load pipeline_state.json
  2. Scan DRF_Downloads/ for all DRF files
  3. For each DRF file:
       a. Always check: should preview be published or republished?
       b. If today == race_date: should final be published?
  4. Save pipeline_state.json
  5. Exit (errors emailed by run_pipeline.bat wrapper)

Idempotent: safe to run repeatedly. Catch up automatically if a tick is missed.
"""

import os
import sys
import json
import logging
from datetime import datetime, timedelta, date
from pathlib import Path

# Make sure THIS file's directory is the first place Python looks for modules.
# Without this, importing run_pipeline.py from a different cwd (e.g. via Task
# Scheduler with a working dir not set) would fail to find drf_schema, score,
# features, etc. — they're all top-level files alongside this one.
_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

# ── BTSM modules ─────────────────────────────────────────────────────────────
# scratches.py + apply_scratches.py + track_status.py live alongside this file.
from scratches import get_scratches, merge_with_manual, ScratchEntry
from track_status import get_track_status, TrackStatus

# ── Paths ────────────────────────────────────────────────────────────────────
BASE_DIR        = Path(__file__).parent.resolve()
DRF_DIR         = Path(r"C:\Users\ryanr\Documents\BTSM\FullAutomation\DRF_Downloads")
STATE_FILE      = BASE_DIR / "pipeline_state.json"
LOG_FILE        = BASE_DIR / "pipeline.log"
KEEP_DAYS       = 7  # Prune state older than this

# Publish window for FINAL sheet (minutes before first post)
FINAL_WINDOW_OPEN_MIN  = 60   # Earliest we'll publish final
FINAL_WINDOW_CLOSE_MIN = 30   # Latest we'll publish final
# i.e., publish final when 30 <= minutes_until_first_post <= 60

# ── Logging ──────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.FileHandler(LOG_FILE, encoding="utf-8"),
              logging.StreamHandler()],
)
log = logging.getLogger(__name__)


# ── State management ─────────────────────────────────────────────────────────

def load_state() -> dict:
    """Load pipeline state, creating empty structure if missing."""
    if not STATE_FILE.exists():
        return {"last_run": None, "published": {}}
    try:
        return json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except Exception as e:
        log.error(f"State file corrupt, starting fresh: {e}")
        return {"last_run": None, "published": {}}


def save_state(state: dict) -> None:
    """Save state, pruning entries older than KEEP_DAYS."""
    cutoff = (date.today() - timedelta(days=KEEP_DAYS)).isoformat()
    state["published"] = {
        d: tracks for d, tracks in state.get("published", {}).items()
        if d >= cutoff
    }
    state["last_run"] = datetime.now().isoformat(timespec="seconds")
    STATE_FILE.write_text(json.dumps(state, indent=2), encoding="utf-8")


# ── DRF file discovery ──────────────────────────────────────────────────────

def parse_drf_filename(path: Path) -> tuple[str, str] | None:
    """
    DRF filename convention: YYYYMMDD_TRACK_DRS.DRF
    Returns (race_date, track) or None.
    """
    name = path.stem  # strip .DRF
    parts = name.split("_")
    if len(parts) < 2:
        return None
    date_str = parts[0]
    track    = parts[1]
    if len(date_str) != 8 or not date_str.isdigit():
        return None
    return date_str, track


def discover_drf_files() -> list[dict]:
    """Return list of {path, race_date, track, mtime} for every DRF in DRF_DIR."""
    if not DRF_DIR.exists():
        log.warning(f"DRF directory does not exist: {DRF_DIR}")
        return []
    out = []
    for p in DRF_DIR.glob("*.DRF"):
        parsed = parse_drf_filename(p)
        if not parsed:
            continue
        race_date, track = parsed
        out.append({
            "path":      p,
            "race_date": race_date,
            "track":     track,
            "mtime":     p.stat().st_mtime,
        })
    return out


# ── First-post extraction from DRF ───────────────────────────────────────────

def get_first_post(drf_path: Path) -> datetime | None:
    """
    Extract first-post time from a DRF file.

    BRISnet DRF files store post times in **Pacific Time** as a 4-digit
    HHMM string (a long-standing industry convention from the simulcast
    network days, where West Coast tracks anchored the daily schedule).
    The actual column varies by DRF schema version but lives near the
    end of the row. We do a heuristic last-40-columns scan looking for
    a single HHMM-shaped value.

    The rest of this pipeline operates in Eastern Time (Equibase publishes
    in ET, and the orchestrator's `datetime.now()` is local — assumed
    Eastern). So we shift Pacific -> Eastern before returning by adding
    3 hours.

    Returns the race-date + HH:MM (ET) as a naive datetime, or None.
    """
    try:
        with open(drf_path, "r", encoding="utf-8", errors="replace") as f:
            first_line = f.readline()
        cols = first_line.split(",")

        # Look for a single HHMM value in the last ~40 cols (post-time region)
        candidates = []
        for i in range(max(0, len(cols) - 40), len(cols)):
            v = cols[i].strip().strip('"')
            if v.isdigit() and len(v) == 4:
                hh, mm = int(v[:2]), int(v[2:])
                if 0 <= hh <= 23 and 0 <= mm <= 59:
                    candidates.append((i, hh, mm))

        if not candidates:
            return None

        # Take the first plausible match — typically the earliest post (race 1)
        _, hh_pt, mm = candidates[0]

        # Build full datetime from filename's race date
        race_date_str = parse_drf_filename(drf_path)[0]
        race_date = datetime.strptime(race_date_str, "%Y%m%d").date()

        # Pacific -> Eastern: +3 hours. Use timedelta to handle day rollover
        # cleanly (e.g. PT 22:00 -> ET 01:00 next day).
        pt_dt = datetime.combine(race_date, datetime.min.time()).replace(
            hour=hh_pt, minute=mm,
        )
        et_dt = pt_dt + timedelta(hours=3)
        return et_dt

    except Exception as e:
        log.warning(f"Could not parse first-post from {drf_path.name}: {e}")
        return None


def _get_final_first_post(drf: dict) -> tuple[datetime | None, TrackStatus | None]:
    """
    Get first-post time for the RACE-DAY (FINAL) path.

    Tries Equibase via track_status.get_track_status() first, then falls
    back to the DRF heuristic. Caches the result on the `drf` dict so a
    single tick that calls this twice (once to gate the window, once to
    record state) only triggers ONE Selenium fetch.

    Returns
    -------
    (first_post, track_status)
        first_post   : datetime or None
        track_status : TrackStatus or None  (None if Equibase fetch failed
                       AND we fell back to DRF — no conditions in that case)
    """
    # Per-tick memoization
    if "_final_first_post_cache" in drf:
        return drf["_final_first_post_cache"]

    track     = drf["track"]
    race_date = drf["race_date"]   # "YYYYMMDD"

    # YYYYMMDD -> (YYYY, MMDD)
    if len(race_date) == 8 and race_date.isdigit():
        year = race_date[:4]
        mmdd = race_date[4:]
    else:
        year, mmdd = None, None

    fp:  datetime | None    = None
    ts:  TrackStatus | None = None

    # --- Equibase (primary) ---
    if mmdd:
        try:
            ts = get_track_status(track, mmdd, year)
            if ts.fetch_ok and ts.first_post:
                fp = ts.first_post
                # %I gives leading zero (e.g. "02:45 PM"); strip it for
                # display. Avoid %-I (Linux-only) and %#I (Windows-only)
                # for cross-platform safety.
                fp_display = fp.strftime("%I:%M %p ET").lstrip("0")
                log.info(
                    f"  first-post for {track} {race_date}: "
                    f"{fp_display} (source=equibase, "
                    f"dirt={ts.dirt_condition or '?'}, "
                    f"turf={ts.turf_condition or '?'})"
                )
            else:
                err = ts.fetch_error or "unknown"
                log.info(
                    f"  Equibase first-post unavailable for {track} {race_date} "
                    f"({err}) — falling back to DRF heuristic"
                )
        except Exception as e:
            log.warning(
                f"  track_status fetch failed for {track} {race_date}: {e} "
                f"— falling back to DRF heuristic"
            )

    # --- DRF heuristic (fallback) ---
    if fp is None:
        fp = get_first_post(drf["path"])
        if fp is not None:
            log.info(
                f"  first-post for {track} {race_date}: "
                f"{fp.strftime('%H:%M')} (source=drf-heuristic)"
            )

    drf["_final_first_post_cache"] = (fp, ts)
    return fp, ts


# ── Stage stubs (replace with real implementations as built) ─────────────────

def pull_scratches(track: str, race_date: str) -> list[dict]:
    """
    Fetch today's scratches for (track, race_date) from the Equibase RSS feed.

    Returns a list of dicts the rest of the pipeline can consume:
        [{"race": 1, "program": "5", "horse": "TEMPORARILYFOREVER",
          "reason": "PrivVet-Illness", "source": "equibase_rss"}, ...]

    Honors the cumulative bulletin format: "Scratched - Re-entered" horses
    are excluded; "Also-Eligible" horses remain on the list (per BTSM rule:
    every DRF entry is scored unless explicitly out, and an AE that hasn't
    been promoted is not running).

    If config.MANUAL_SCRATCHES is set AND the active config track/date
    matches this (track, race_date), those are merged in as well — useful
    for operator overrides on the track currently being scored manually.

    Network failures are LOGGED, not raised. Returning an empty list on
    Equibase outage lets the FINAL pipeline still run with whatever scratch
    info was available (manual extras, or none).

    `race_date` arrives here in YYYYMMDD form from the DRF filename.
    scratches.get_scratches() expects MMDD + year, so we slice it.
    """
    # YYYYMMDD -> (YYYY, MMDD)
    if len(race_date) != 8 or not race_date.isdigit():
        log.warning(f"  pull_scratches: bad race_date {race_date!r}; returning []")
        return []
    year   = race_date[:4]
    mmdd   = race_date[4:]

    rss_scratches: list[ScratchEntry] = []
    try:
        rss_scratches = get_scratches(track, mmdd, year)
    except Exception as e:
        log.warning(
            f"  pull_scratches: Equibase fetch failed for {track} {race_date} "
            f"({e}) — proceeding with manual scratches only."
        )

    # Merge with config.MANUAL_SCRATCHES if (and only if) the operator's
    # active config matches this (track, date). This avoids leaking manual
    # entries from one track's scoring run into other tracks' final sheets.
    manual_entries: list[tuple[int, str]] = []
    try:
        import config
        active_yyyymmdd = f"{config.YEAR}{config.RACE_DATE}"
        if (track.upper() == config.TRACK.upper() and
                race_date == active_yyyymmdd and
                config.MANUAL_SCRATCHES):
            manual_entries = list(config.MANUAL_SCRATCHES)
            log.info(
                f"  pull_scratches: applying {len(manual_entries)} manual "
                f"scratch(es) from config for {track} {race_date}"
            )
    except Exception as e:
        log.debug(f"  pull_scratches: config not consulted ({e})")

    if manual_entries:
        all_scratches = merge_with_manual(rss_scratches, manual_entries)
    else:
        all_scratches = list(rss_scratches)

    out = [
        {
            "race":    s.race,
            "program": s.program_number,
            "horse":   s.horse_name,
            "reason":  s.reason,
            "source":  s.source,
        }
        for s in all_scratches
    ]
    log.info(
        f"  pull_scratches({track}, {race_date}) -> {len(out)} scratch(es) "
        f"(rss={len(rss_scratches)}, manual={len(manual_entries)})"
    )
    return out


def run_scoring(
    track: str,
    race_date: str,
    scratches: list[dict] | None = None,
    track_status: TrackStatus | None = None,
) -> Path | None:
    """
    Real scoring implementation. Pipeline order:

        ingest_drf.load_drf()
            -> apply_scratches  (CRITICAL: must precede feature engineering)
            -> features.engineer_features
            -> score.run_scoring
            -> output.generate_excel

    Why scratches BEFORE features? Most engineered fields are race-level
    aggregates (means, stds, ranks, normalized variables). Including
    scratched horses corrupts every active horse's comparison baseline:
    field size is wrong, baseprob is depressed, ranks are off, and
    standard-deviation columns get the wrong spread. Scratches must be
    removed first.

    Returns path to the produced .xlsx file, or None on failure.

    Parameters
    ----------
    track : str
        BRISnet/BTSM track code from the DRF filename (e.g. "CD", "KEE").
    race_date : str
        YYYYMMDD date string from the DRF filename.
    scratches : list of dicts, optional
        Output of pull_scratches(). For PREVIEW runs, pass None.
    track_status : TrackStatus, optional
        For FINAL runs, the Equibase snapshot. Passes dirt/turf condition
        through to the Excel summary sheet. None for PREVIEW.

    Notes
    -----
    Currently only runs scoring when `track` matches `config.TRACK`. The
    coefficient files in `config.DIRT_MODELS` / `TURF_MODELS` / `MAIDEN_MODELS`
    are meet-specific (e.g. "keedirt042026c.sas7bdat"). The model registry
    maps each track to the appropriate model family — currently every track
    falls back to "KEE" (the default), but as you build SAR/CD/etc. models,
    register them in model_registry.py and they take precedence for those
    tracks automatically.
    """
    import config
    from ingest_drf import load_drf
    from apply_scratches import apply_scratches
    from features import engineer_features
    from score import run_scoring as score_run_scoring
    from output import generate_excel
    from scratches import ScratchEntry
    from model_registry import get_scoring_models
    from model_setup import setup_registry

    log.info(f"  run_scoring({track}, {race_date}, scratches={len(scratches or [])})")

    # ── 1. Resolve which model family to use for this track ──────────────
    # setup_registry() bootstraps from config and applies any per-track
    # overrides defined in model_setup.py. Idempotent.
    setup_registry(config)
    scoring_config = get_scoring_models(track, underlying_config=config)
    log.info(
        f"  Using model family {scoring_config.family_name!r} for track {track!r} "
        f"({len(scoring_config.DIRT_MODELS)} dirt, "
        f"{len(scoring_config.TURF_MODELS)} turf, "
        f"{len(scoring_config.MAIDEN_MODELS)} maiden models)"
    )

    # ── 2. Locate the DRF file ───────────────────────────────────────────
    # Filenames discovered by the orchestrator are YYYYMMDD_TRACK_DRS.DRF
    # (e.g. "20260508_CD_DRS.DRF"). config.DRF_FILE points to a different
    # convention (TRACK + MMDD), but we have a real path passed via the
    # scoring chain. Build the path from the orchestrator's discovery.
    drf_filename_candidates = [
        DRF_DIR / f"{race_date}_{track}_DRS.DRF",
        DRF_DIR / f"{track}{race_date[4:]}.DRF",   # e.g. CDX0508.DRF
        config.DRF_FILE,                            # last resort
    ]
    drf_path = None
    for cand in drf_filename_candidates:
        if cand and Path(cand).exists():
            drf_path = Path(cand)
            break
    if drf_path is None:
        log.error(
            f"  run_scoring: no DRF file found for {track} {race_date}. "
            f"Tried: {[str(c) for c in drf_filename_candidates if c]}"
        )
        return None

    # ── 3. Load DRF ──────────────────────────────────────────────────────
    year = race_date[:4]
    mmdd = race_date[4:]
    log.info(f"  Loading DRF: {drf_path.name}")
    df = load_drf(drf_path, track=track, date=mmdd, year=year)
    initial_n = len(df)
    log.info(f"  Loaded {initial_n} horses across {df['Race'].nunique()} races")

    # ── 4. Apply scratches BEFORE features ───────────────────────────────
    if scratches:
        # Convert dicts back into ScratchEntry objects for apply_scratches.
        scratch_entries = [
            ScratchEntry(
                race=int(s["race"]),
                program_number=str(s["program"]),
                horse_name=s.get("horse", ""),
                reason=s.get("reason", ""),
                source=s.get("source", "unknown"),
            )
            for s in scratches
        ]
        df, scr_summary = apply_scratches(df, scratch_entries)
        log.info(
            f"  Scratches applied: {scr_summary.rows_dropped} dropped "
            f"({initial_n} -> {scr_summary.rows_after})"
        )
        if scr_summary.unmatched:
            for s in scr_summary.unmatched:
                log.warning(
                    f"    Unmatched scratch (not in DRF): "
                    f"race {s.race} #{s.program_number} {s.horse_name}"
                )

    # ── 5. Feature engineering (race-level stats now correct) ────────────
    log.info(f"  Engineering features on {len(df)} horses...")
    feature_df = engineer_features(df)

    # ── 6. Scoring ───────────────────────────────────────────────────────
    log.info(f"  Running scoring engine...")
    scored_df = score_run_scoring(
        feature_df, scoring_config.COEFF_DIR, scoring_config
    )

    # ── 7. Write Excel ───────────────────────────────────────────────────
    # Output filename: YYYYMMDD_TRACK_(PREVIEW|FINAL).xlsx in the configured
    # output dir. Don't overwrite the user's manual config.OUTPUT_XLSX.
    label = "FINAL" if scratches is not None else "PREVIEW"
    out_path = config.OUTPUT_DIR / f"{race_date}_{track}_{label}.xlsx"

    dirt_cond = (track_status.dirt_condition if track_status else "") or ""
    turf_cond = (track_status.turf_condition if track_status else "") or ""

    full_track_name = (
        getattr(config, "TRACK_FULL_NAMES", {}).get(track.upper(), track)
    )

    log.info(f"  Generating Excel: {out_path}")
    generate_excel(
        scored_df=scored_df,
        feature_df=feature_df,
        output_path=out_path,
        config=scoring_config,
        track=full_track_name,
        race_date=race_date,
        dirt_condition=dirt_cond,
        turf_condition=turf_cond,
    )

    log.info(f"  run_scoring complete: {out_path.name}")
    return out_path


def generate_pdf(track: str, race_date: str, score_path: Path,
                 is_final: bool = False) -> Path | None:
    """
    PLACEHOLDER. To be implemented (ReportLab or WeasyPrint).
    Returns path to generated PDF.
    """
    label = "FINAL" if is_final else "PREVIEW"
    log.info(f"  [stub] generate_pdf({track}, {race_date}, {label})")
    return BASE_DIR / f"_stub_{race_date}_{track}_{label}.pdf"


def upload_to_btsm(pdf_path: Path, track: str, race_date: str,
                   is_final: bool = False) -> bool:
    """
    PLACEHOLDER. To be implemented (SFTP or CMS API).
    Returns True on success.
    """
    label = "FINAL" if is_final else "PREVIEW"
    log.info(f"  [stub] upload_to_btsm({pdf_path.name}, {track}, {race_date}, {label})")
    return True


# ── Per-track decision logic ─────────────────────────────────────────────────

def should_publish_preview(drf: dict, state: dict) -> tuple[bool, str]:
    """
    Decide if a preview sheet should be published for this DRF.
    Returns (should_publish, reason).
    """
    race_date = drf["race_date"]
    track     = drf["track"]
    mtime     = drf["mtime"]

    pub = state.get("published", {}).get(race_date, {}).get(track, {})
    prev = pub.get("preview")

    if not prev:
        return True, "no preview yet"

    # Re-publish if DRF file has been updated since last preview
    if prev.get("drf_mtime", 0) < mtime - 1:  # 1-sec tolerance
        return True, "DRF file updated"

    return False, "preview already current"


def should_publish_final(drf: dict, state: dict, now: datetime) -> tuple[bool, str]:
    """
    Decide if the FINAL sheet should be published right now.
    Returns (should_publish, reason).

    Conditions:
      - race_date == today
      - final not already published
      - first_post is parseable (Equibase primary, DRF fallback)
      - 30 <= minutes_until_first_post <= 60
    """
    race_date = drf["race_date"]
    track     = drf["track"]

    # Only on race day
    today_str = now.date().strftime("%Y%m%d")
    if race_date != today_str:
        return False, "not race day"

    pub = state.get("published", {}).get(race_date, {}).get(track, {})
    if pub.get("final"):
        return False, "final already published"

    # Equibase first, DRF heuristic fallback. Result is cached on `drf`
    # so the subsequent publish_final() call doesn't re-fetch Equibase.
    fp, _ts = _get_final_first_post(drf)
    if not fp:
        return False, "could not parse first post"

    minutes_until = (fp - now).total_seconds() / 60.0

    if minutes_until > FINAL_WINDOW_OPEN_MIN:
        return False, f"too early ({minutes_until:.0f} min until first post)"
    if minutes_until < FINAL_WINDOW_CLOSE_MIN:
        return False, f"too late ({minutes_until:.0f} min until first post)"

    return True, f"in window ({minutes_until:.0f} min until first post)"


# ── Publish actions ──────────────────────────────────────────────────────────

def publish_preview(drf: dict, state: dict) -> bool:
    """Run the preview pipeline. Update state on success."""
    race_date = drf["race_date"]
    track     = drf["track"]

    log.info(f"[PREVIEW] {track} {race_date} -- starting")
    try:
        # No scratches for preview
        score_path = run_scoring(track, race_date, scratches=None)
        if not score_path:
            log.error(f"[PREVIEW] {track} {race_date} -- scoring failed")
            return False

        pdf_path = generate_pdf(track, race_date, score_path, is_final=False)
        if not pdf_path:
            log.error(f"[PREVIEW] {track} {race_date} -- PDF generation failed")
            return False

        if not upload_to_btsm(pdf_path, track, race_date, is_final=False):
            log.error(f"[PREVIEW] {track} {race_date} -- upload failed")
            return False

        # Update state
        state.setdefault("published", {}).setdefault(race_date, {}).setdefault(track, {})
        state["published"][race_date][track]["preview"] = {
            "published_at": datetime.now().isoformat(timespec="seconds"),
            "drf_file":     drf["path"].name,
            "drf_mtime":    drf["mtime"],
            "score_xlsx":   str(score_path),
            "pdf":          str(pdf_path),
        }
        log.info(f"[PREVIEW] {track} {race_date} -- OK")
        return True

    except Exception as e:
        log.exception(f"[PREVIEW] {track} {race_date} -- exception: {e}")
        return False


def publish_final(drf: dict, state: dict) -> bool:
    """Run the final pipeline (with scratches). Update state on success."""
    race_date = drf["race_date"]
    track     = drf["track"]

    log.info(f"[FINAL]   {track} {race_date} -- starting")
    try:
        scratches = pull_scratches(track, race_date)

        # Pull cached Equibase status from the per-tick cache populated in
        # should_publish_final(). If for some reason the cache is empty
        # (e.g. publish_final() called directly), the helper re-fetches.
        first_post, ts = _get_final_first_post(drf)

        # Run scoring with track conditions so they flow into the Excel summary
        score_path = run_scoring(
            track, race_date, scratches=scratches, track_status=ts,
        )
        if not score_path:
            log.error(f"[FINAL]   {track} {race_date} -- scoring failed")
            return False

        pdf_path = generate_pdf(track, race_date, score_path, is_final=True)
        if not pdf_path:
            log.error(f"[FINAL]   {track} {race_date} -- PDF generation failed")
            return False

        if not upload_to_btsm(pdf_path, track, race_date, is_final=True):
            log.error(f"[FINAL]   {track} {race_date} -- upload failed")
            return False

        track_status_dict = ts.as_dict() if ts is not None else None

        state.setdefault("published", {}).setdefault(race_date, {}).setdefault(track, {})
        state["published"][race_date][track]["final"] = {
            "published_at":   datetime.now().isoformat(timespec="seconds"),
            "first_post":     first_post.isoformat(timespec="seconds") if first_post else None,
            "first_post_source": (
                "equibase" if (ts is not None and ts.fetch_ok and ts.first_post)
                else ("drf-heuristic" if first_post else None)
            ),
            "track_status":   track_status_dict,   # full Equibase snapshot (None on fallback)
            "scratch_count":  len(scratches),
            "scratches":      scratches,           # full per-scratch detail for audit
            "score_xlsx":     str(score_path),     # path to the scored Excel
            "pdf":            str(pdf_path),
        }
        log.info(f"[FINAL]   {track} {race_date} -- OK")
        return True

    except Exception as e:
        log.exception(f"[FINAL]   {track} {race_date} -- exception: {e}")
        return False


# ── Main ─────────────────────────────────────────────────────────────────────

def main() -> int:
    log.info("=" * 60)
    log.info(f"  Pipeline poller tick @ {datetime.now():%Y-%m-%d %H:%M}")
    log.info("=" * 60)

    state = load_state()
    drfs = discover_drf_files()
    log.info(f"[*] {len(drfs)} DRF files found in {DRF_DIR}")

    if not drfs:
        save_state(state)
        log.info("[*] Nothing to do.")
        return 0

    now = datetime.now()
    failures = []
    actions  = 0

    for drf in sorted(drfs, key=lambda d: (d["race_date"], d["track"])):
        race_date = drf["race_date"]
        track     = drf["track"]

        # PREVIEW decision
        publish_p, reason_p = should_publish_preview(drf, state)
        if publish_p:
            actions += 1
            if not publish_preview(drf, state):
                failures.append(f"PREVIEW {track} {race_date}")
                save_state(state)  # save partial state even on failure
        else:
            log.debug(f"[skip preview] {track} {race_date}: {reason_p}")

        # FINAL decision (only relevant on race day)
        publish_f, reason_f = should_publish_final(drf, state, now)
        if publish_f:
            actions += 1
            if not publish_final(drf, state):
                failures.append(f"FINAL {track} {race_date}")
                save_state(state)
        else:
            log.debug(f"[skip final]   {track} {race_date}: {reason_f}")

    save_state(state)

    log.info("=" * 60)
    log.info(f"  Actions taken: {actions}  |  Failures: {len(failures)}")
    if failures:
        log.error("  Failed: " + ", ".join(failures))
    log.info("=" * 60)

    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
